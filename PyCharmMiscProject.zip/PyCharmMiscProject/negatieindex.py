a = "python"
print(a[-3:])