name=input("enter your name")
age=input("enter your age")
print(f"Hello {name} \n you will turn 100 in the 2026")