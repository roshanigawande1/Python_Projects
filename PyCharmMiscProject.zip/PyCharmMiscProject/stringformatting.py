price=3.5
quantity=5
print("the price is ",price)
print("the quantity is %d"%quantity)
print("the price is %s and quantity is %s and total cost is %s"%(price,quantity ,price*quantity))