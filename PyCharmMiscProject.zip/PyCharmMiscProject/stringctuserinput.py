str1=input("enter 1st string: ")
str2=input("enter 2nd string: ")

print(f"{str1[0]}{str2[-1]}")