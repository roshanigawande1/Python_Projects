tasks=["grocery", "cleaning", "laundry", "cooking", "shopping"]
completed_tasks = []
incomplete_tasks = []
for task in tasks:
    answer = input(f"Have you completed the task '{task}'? (yes/no): ")
    if answer.lower() == 'yes':
        completed_tasks.append(task)
    else:
        incomplete_tasks.append(task)

print("\nCompleted Tasks:",completed_tasks)
print("\nIncomplete Tasks:", incomplete_tasks)