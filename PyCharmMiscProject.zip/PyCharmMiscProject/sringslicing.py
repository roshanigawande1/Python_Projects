a="I love  Python 3"
b="Welcome to Class"

print("%s %s "%(a[0:6],b[-5:])) #here used string formatting with slicing

print(a[0:7],b[11:])