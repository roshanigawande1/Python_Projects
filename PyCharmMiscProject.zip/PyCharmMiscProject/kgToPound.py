weight=int(input("Enter your weight:"))
opt=input("If your weight is in kg's then pressed K or L if it is in Pound:")
if opt.upper()=='K':
    pound=weight*2.20
    print(f"Your weight in Pound is {pound}")
elif opt.upper()=='L':
    kg=weight/2.20
    print(f"Your weight in kg is {kg}")
else:
    print("Incorrect option")