print("First Program - Python print funtion")
print("It is declared like this :")
print("print('what to print')")

print("\nFirst Program - Python print funtion\nIt is declared like this :\nprint('what to print')")
