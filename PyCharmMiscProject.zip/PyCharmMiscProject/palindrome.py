str1=input("Enter a string : ")
str2=str1[::-1]
if str1 == str2:
    print("string is palindrome")
else:
    print("string is not palindrome")