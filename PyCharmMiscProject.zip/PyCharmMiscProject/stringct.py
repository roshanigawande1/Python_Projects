print("Hello"+" "+"Roshani")

print('String Manipulation Exercise\nString concatenation is done with "+" sign\ne.g print("Hello"+"Roshani")\nNew lines can be created with a backslash and n')

