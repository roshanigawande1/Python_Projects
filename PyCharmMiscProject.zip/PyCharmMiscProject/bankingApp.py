def check_balance():
    print(f"Your balance is: ${balance}")
  
    

def deposit():
    global balance
    amt_added = float(input("Enter the amount to deposit: "))
    balance += amt_added
    print(f"Your new balance is: ${balance}")


def withdraw():
    global balance
    amt_withdrawn = float(input("Enter the amount to withdraw: "))
    if amt_withdrawn > balance:
        print("Insufficient funds. Please try again.")
    else:
        balance -= amt_withdrawn
        print(f"Your new balance is: ${balance}")   

balance=0


while True:
    print("Welcome to Rosh Bank!!!")
    print("1. Check Balance")
    print("2. Deposite")
    print("3. Withdraw")    
    print("4. Exit")

    choice=int(input("Please select an option: "))


    if choice == 1:
        check_balance()
    elif choice == 2:
        deposit()
    elif choice == 3:
        withdraw()
    elif choice == 4:
        break
    else:
        print("Invalid option. Please try again.")


print("Thank you for banking with us. Have a great day!")    

