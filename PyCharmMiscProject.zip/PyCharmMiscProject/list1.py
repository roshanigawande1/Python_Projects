'''
l1=[1,2,3]
l1.extend([3,4])
print(l1)
'''
l2=["mango","apple","grape","banana","apple"]
#l2.sort(reverse=True )
#print(l2)


for i in set(l2) :
  occur=l2.count(i)
  if occur > 1:
    print("duplicate item :",i)
