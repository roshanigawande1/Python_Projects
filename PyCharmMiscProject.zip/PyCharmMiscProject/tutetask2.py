fn=(input("Enter the first name : "))
ln=(input("Enter the Second Name : "))

print(f"{fn} {ln} ! Welcome to the python program")