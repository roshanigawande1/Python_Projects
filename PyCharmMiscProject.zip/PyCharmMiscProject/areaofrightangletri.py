hi=float(input("Enter a height:"))
base=float(input("Enter a base :"))
area=1/2*hi*base;
print("Area of right angle triangle is ",area)