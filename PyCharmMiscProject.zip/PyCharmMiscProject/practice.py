counter=0
while counter<=10:
    print(counter)
    counter = counter+ 1
    