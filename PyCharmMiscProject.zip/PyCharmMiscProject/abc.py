score={3:2,4:6,1:7,8:42,9:21}
print(max(score))