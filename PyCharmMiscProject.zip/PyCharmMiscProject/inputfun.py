#print ("Hello "+input("what is your name? ")) #is used for comment

print("Hey "+input("what is your name? ")+","+"How are you ?")