def add(a, b):
    print("Addition:", a + b)

def subtract(a, b):
    print("Subtraction:", a - b)

def multiply(a, b):
    print("Multiplication:", a * b)

def divide(a, b):
    if b != 0:
        print("Division:", a / b)
    else:
        print("Error: Division by zero is not allowed.")

def calculator():
    while True:
        try:
            operation = input("\nEnter operation (add, subtract, multiply, divide): ").strip().lower()
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
            
            if operation == "add":
                add(a, b)
            elif operation == "subtract":
                subtract(a, b)
            elif operation == "multiply":
                multiply(a, b)
            elif operation == "divide":
                divide(a, b)
            else:
                print("Invalid operation. Please try again.")
        except ValueError:
            print("Invalid input. Please enter numeric values.")

        again = input("\nDo you want to perform another calculation? (yes/no): ").strip().lower()

        if again != "yes":
            print("Exiting the calculator. Goodbye!")
            break

print("Welcome to the Calculator!")
calculator()


